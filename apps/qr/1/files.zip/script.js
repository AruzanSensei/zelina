const params = new URLSearchParams(window.location.search);
const id = params.get('id');

function renderProduct(p) {
  const app = document.getElementById('app');
  const statusClass = p.status === 'aktif' ? 'status-aktif' : 'status-nonaktif';
  const statusLabel = p.status === 'aktif' ? 'AKTIF' : 'TIDAK AKTIF';

  const qrLink = `https://qr.zanxa.site/product/${p.id}`;

  // Photo gallery slots
  const photoSlots = [
    { key: 'gambar_depan',        label: 'Depan' },
    { key: 'gambar_samping_kanan',label: 'Samping Kanan' },
    { key: 'gambar_samping_kiri', label: 'Samping Kiri' },
    { key: 'gambar_belakang',     label: 'Belakang' },
    { key: 'gambar_dalam',        label: 'Dalam' },
  ];

  const galleryHTML = photoSlots
    .filter(s => p[s.key])
    .map(s => `
      <div class="gallery-item">
        <img src="${p[s.key]}" alt="${s.label}" class="gallery-img" loading="lazy" />
        <span class="gallery-label">${s.label}</span>
      </div>
    `).join('');

  app.innerHTML = `
    <div class="product-content fade-in">

      <!-- COVER -->
      <div class="product-cover-wrap">
        <img src="${p.gambar_cover || p.gambar_depan}" alt="${p.nama_produk}" class="product-cover-img" />
        <div class="cover-overlay">
          <span class="product-id-badge">${p.id}</span>
          <span class="product-status ${statusClass}">${statusLabel}</span>
        </div>
      </div>

      <!-- TOP GRID -->
      <div class="product-top">
        <div class="product-info">
          <div class="info-header">
            <span class="product-type-tag">${p.tipe}</span>
          </div>
          <h1 class="product-name">${p.nama_produk}</h1>
          ${p.spesifikasi ? `<p class="product-spec">${p.spesifikasi}</p>` : ''}

          <!-- SPECS TABLE -->
          <div class="info-grid">
            <div class="info-item">
              <span class="info-key">NO. SERI</span>
              <span class="info-val mono">${p.nomor_seri}</span>
            </div>
            <div class="info-item">
              <span class="info-key">TAHUN</span>
              <span class="info-val mono">${p.tahun_pembuatan}</span>
            </div>
            <div class="info-item">
              <span class="info-key">TIPE / KODE</span>
              <span class="info-val">${p.tipe}</span>
            </div>
            <div class="info-item">
              <span class="info-key">JUMLAH SOCKET</span>
              <span class="info-val mono">${p.jumlah_socket ?? '—'}</span>
            </div>
            <div class="info-item span2">
              <span class="info-key">INPUT</span>
              <span class="info-val">${p.input || '—'}</span>
            </div>
            <div class="info-item span2">
              <span class="info-key">OUTPUT</span>
              <span class="info-val">${p.output || '—'}</span>
            </div>
            <div class="info-item span2">
              <span class="info-key">FREKUENSI</span>
              <span class="info-val">${p.frekuensi || '—'}</span>
            </div>
          </div>
        </div>

        <!-- QR -->
        <div class="qr-panel">
          <div class="demo-label">QR CODE</div>
          <div id="qr-canvas"></div>
          <span class="mono qr-url">qr.zanxa.site/product/${p.id}</span>
        </div>
      </div>

      <!-- PHOTO GALLERY -->
      ${galleryHTML ? `
      <div class="gallery-section">
        <div class="section-label">FOTO PRODUK</div>
        <div class="gallery-grid">${galleryHTML}</div>
      </div>` : ''}

    </div>
  `;

  new QRCode(document.getElementById('qr-canvas'), {
    text: qrLink,
    width: 120,
    height: 120,
    colorDark: '#0a0a0a',
    colorLight: '#f5f0e8',
  });
}

function showNotFound() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="error-screen fade-in">
      <div class="error-code">404</div>
      <div class="error-title">Produk Tidak Ditemukan</div>
      <p class="error-sub">ID "<span class="mono">${id || '—'}</span>" tidak terdaftar dalam sistem.</p>
      <a href="index.html" class="error-btn">← Kembali ke Beranda</a>
    </div>
  `;
  document.title = 'Tidak Ditemukan — QR Zanxa';
}

function showError() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="error-screen fade-in">
      <div class="error-code">ERR</div>
      <div class="error-title">Gagal Mengambil Data</div>
      <p class="error-sub">Tidak dapat memuat database produk. Coba lagi nanti.</p>
      <a href="index.html" class="error-btn">← Kembali ke Beranda</a>
    </div>
  `;
}

function removeSkeleton() {
  const sk = document.getElementById('skeleton');
  if (sk) sk.remove();
}

if (!id) {
  removeSkeleton();
  showNotFound();
} else {
  document.title = `Produk ${id} — QR Zanxa`;
  fetch('data/product.json')
    .then(res => {
      if (!res.ok) throw new Error('fetch failed');
      return res.json();
    })
    .then(data => {
      removeSkeleton();
      const product = data.find(item => item.id === id.toUpperCase());
      if (product) {
        renderProduct(product);
      } else {
        showNotFound();
      }
    })
    .catch(() => {
      removeSkeleton();
      showError();
    });
}
